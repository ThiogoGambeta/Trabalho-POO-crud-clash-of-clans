# Trabalho-POO-crud-produtos
Trabalho da matéria de Programação orientada a objetos, com intuito de criar um crud em java com o tema produtos
