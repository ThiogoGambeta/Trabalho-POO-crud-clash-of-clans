# 🃏 Clash Royale Cards Manager

Sistema de gerenciamento de cartas do Clash Royale desenvolvido com Spring Boot.

## 📋 Sobre o Projeto

Este é um sistema web para cadastro, visualização e gerenciamento de cartas do jogo Clash Royale. O projeto permite criar, editar, visualizar e listar todas as cartas com suas respectivas características e atributos.

## ✨ Funcionalidades

- ✅ Cadastro de novas cartas
- ✅ Listagem de todas as cartas
- ✅ Visualização detalhada de cada carta
- ✅ Edição de cartas existentes
- ✅ Upload de imagens em base64
- ✅ Interface responsiva e moderna

## 🎮 Atributos das Cartas

Cada carta possui os seguintes atributos:

- **Código**: Identificador único da carta
- **Nome**: Nome da carta
- **Dano**: Quantidade de dano causado
- **Velocidade de Ataque**: Tempo entre ataques (em segundos)
- **Velocidade na Arena**: Velocidade de movimentação
- **Tipo de Dano**: Dano em área ou dano único
- **Imagem**: Imagem da carta (suporta base64)

## 🚀 Tecnologias Utilizadas

- **Java 17+**
- **Spring Boot**
- **Spring Data JPA**
- **Hibernate**
- **Thymeleaf** (Template Engine)
- **Maven** (Gerenciador de dependências)
- **Banco de Dados H2** (desenvolvimento)
- **Lombok**
- **Jakarta Validation**

## 📦 Estrutura do Projeto

```
clash-royale-app/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── br/edu/faculdade/clash_royale_app/
│   │   │       ├── entity/          # Entidades JPA
│   │   │       ├── controller/      # Controllers MVC
│   │   │       ├── service/         # Camada de serviços
│   │   │       └── repository/      # Repositórios JPA
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── static/              # CSS, JS, imagens
│   │       └── templates/           # Templates Thymeleaf
│   └── test/                        # Testes unitários
├── pom.xml
└── README.md
```

## 🛠️ Como Executar o Projeto

### Pré-requisitos

- Java 17 ou superior
- Maven 3.6+

### Passos para execução

1. **Clone o repositório**
   ```bash
   git clone <url-do-repositorio>
   cd clash-royale-app
   ```

2. **Execute o projeto usando Maven Wrapper**
   
   **Windows:**
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```
   
   **Linux/Mac:**
   ```bash
   ./mvnw spring-boot:run
   ```

3. **Acesse a aplicação**
   
   Abra seu navegador e acesse: `http://localhost:8080`

## 🗃️ Banco de Dados

O projeto utiliza banco de dados H2 em memória por padrão para facilitar o desenvolvimento. As configurações podem ser ajustadas no arquivo `application.properties`.

### Características do modelo de dados:

- A entidade `CartaEntity` possui suporte para imagens em base64 através do campo `imagemUrl` configurado como `@Lob` com tipo `TEXT` no banco de dados, permitindo armazenar strings grandes (até ~2GB dependendo do banco).

## 🎨 Interface

A aplicação possui uma interface moderna e responsiva com:

- Gradientes coloridos
- Cards estilizados
- Ícones intuitivos
- Design mobile-first
- Animações suaves

## 📝 Rotas Principais

- `/cartas` - Lista todas as cartas
- `/cartas/{codigo}` - Visualiza detalhes de uma carta específica
- `/cartas/nova` - Formulário para cadastrar nova carta
- `/cartas/{codigo}/editar` - Formulário para editar carta existente

## 👨‍💻 Desenvolvimento

### Compilar o projeto
```bash
.\mvnw.cmd clean install
```

### Executar testes
```bash
.\mvnw.cmd test
```

### Gerar o JAR
```bash
.\mvnw.cmd package
```

O arquivo JAR será gerado em `target/clash-royale-app-{version}.jar`

## 📄 Licença

Este projeto foi desenvolvido para fins educacionais.

## 🎓 Projeto Acadêmico

Desenvolvido como projeto da faculdade para demonstrar conhecimentos em:
- Desenvolvimento web com Spring Boot
- Padrão MVC
- Persistência de dados com JPA/Hibernate
- Template engines (Thymeleaf)
- Validação de dados
- Design responsivo

---

⚔️ Feito com Spring Boot e ❤️
