package br.edu.faculdade.clash_of_clans_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClashOfClansAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClashOfClansAppApplication.class, args);
	}

}
